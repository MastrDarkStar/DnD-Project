﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_DnD_Generator
{
    class WeaponHealth : LevelAgeStats
    {
        Random rnd = new Random();
        private int picker;
        public string weapon;
        public int HP;
        private int RoughHP;

        public void Health()
        {

        }
        public void Health(int Level)
        {
            RoughHP = rnd.Next(1, 6);
            genConstitution();
            HP = ((Constitution/2) * Level) + (Level * 8);
        }
        public void Weapons()
        {
            genDexterity();
            genStrength();
            if (Strength > Dexterity)
            {
                picker = rnd.Next(1, 3);
                if (picker == 1)
                {
                    weapon = "GreatSword";
                }
                if (picker == 2)
                {
                    weapon = "Maul";
                }
                if (picker == 3)
                {
                    weapon = "Broadsword";
                }
            }
            else if (Dexterity > Strength)
            {
                picker = rnd.Next(1, 3);
                if (picker == 1)
                {
                    weapon = "Rapier";
                }
                if (picker == 2)
                {
                    weapon = "Dagger";
                }
                if (picker == 3)
                {
                    weapon = "Bow+Arrows";
                }
            }
            else
            {
                picker = rnd.Next(1, 3);
                if (picker == 1)
                {
                    weapon = "Club";
                }
                if (picker == 2)
                {
                    weapon = "Dagger";
                }
                if (picker == 3)
                {
                    weapon = "ShortSword";
                }
            }
        }

    }
}
