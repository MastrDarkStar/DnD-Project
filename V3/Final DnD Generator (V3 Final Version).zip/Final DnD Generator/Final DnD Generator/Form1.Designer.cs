﻿namespace Final_DnD_Generator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Start = new System.Windows.Forms.Button();
            this.NameBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.DiseaseCheck = new System.Windows.Forms.CheckBox();
            this.MonsterCheck = new System.Windows.Forms.CheckBox();
            this.AgeBox = new System.Windows.Forms.TextBox();
            this.LevelBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.textBoxAge = new System.Windows.Forms.TextBox();
            this.textBoxLevel = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.StrengthBox = new System.Windows.Forms.TextBox();
            this.DexterityBox = new System.Windows.Forms.TextBox();
            this.ConstitutionBox = new System.Windows.Forms.TextBox();
            this.IntelligenceBox = new System.Windows.Forms.TextBox();
            this.WisdomBox = new System.Windows.Forms.TextBox();
            this.CharismaBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.QuirkBox = new System.Windows.Forms.TextBox();
            this.IdealBox = new System.Windows.Forms.TextBox();
            this.BondBox = new System.Windows.Forms.TextBox();
            this.TraitBox = new System.Windows.Forms.TextBox();
            this.FlawBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.TypeBox = new System.Windows.Forms.TextBox();
            this.DiseaseBox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.WeaponBox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.HPBox = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Start
            // 
            this.Start.Location = new System.Drawing.Point(12, 148);
            this.Start.Name = "Start";
            this.Start.Size = new System.Drawing.Size(139, 50);
            this.Start.TabIndex = 0;
            this.Start.Text = "Generate";
            this.Start.UseVisualStyleBackColor = true;
            this.Start.Click += new System.EventHandler(this.StartClick);
            // 
            // NameBox
            // 
            this.NameBox.Location = new System.Drawing.Point(181, 12);
            this.NameBox.Name = "NameBox";
            this.NameBox.Size = new System.Drawing.Size(208, 22);
            this.NameBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Please enter their name";
            // 
            // DiseaseCheck
            // 
            this.DiseaseCheck.AutoSize = true;
            this.DiseaseCheck.Location = new System.Drawing.Point(12, 121);
            this.DiseaseCheck.Name = "DiseaseCheck";
            this.DiseaseCheck.Size = new System.Drawing.Size(97, 21);
            this.DiseaseCheck.TabIndex = 3;
            this.DiseaseCheck.Text = "Diseased?";
            this.DiseaseCheck.UseVisualStyleBackColor = true;
            // 
            // MonsterCheck
            // 
            this.MonsterCheck.AutoSize = true;
            this.MonsterCheck.Location = new System.Drawing.Point(12, 94);
            this.MonsterCheck.Name = "MonsterCheck";
            this.MonsterCheck.Size = new System.Drawing.Size(125, 21);
            this.MonsterCheck.TabIndex = 4;
            this.MonsterCheck.Text = "Monster Type?";
            this.MonsterCheck.UseVisualStyleBackColor = true;
            // 
            // AgeBox
            // 
            this.AgeBox.Location = new System.Drawing.Point(181, 40);
            this.AgeBox.Name = "AgeBox";
            this.AgeBox.Size = new System.Drawing.Size(100, 22);
            this.AgeBox.TabIndex = 5;
            // 
            // LevelBox
            // 
            this.LevelBox.AccessibleName = "Form1.LevelBox.Text";
            this.LevelBox.Location = new System.Drawing.Point(181, 68);
            this.LevelBox.Name = "LevelBox";
            this.LevelBox.Size = new System.Drawing.Size(100, 22);
            this.LevelBox.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "What\'s their rough age?";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "What\'s their level?";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(421, 12);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(340, 22);
            this.richTextBox1.TabIndex = 9;
            this.richTextBox1.Text = "";
            // 
            // textBoxAge
            // 
            this.textBoxAge.Location = new System.Drawing.Point(476, 37);
            this.textBoxAge.Name = "textBoxAge";
            this.textBoxAge.Size = new System.Drawing.Size(100, 22);
            this.textBoxAge.TabIndex = 10;
            // 
            // textBoxLevel
            // 
            this.textBoxLevel.Location = new System.Drawing.Point(661, 37);
            this.textBoxLevel.Name = "textBoxLevel";
            this.textBoxLevel.Size = new System.Drawing.Size(100, 22);
            this.textBoxLevel.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(437, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 17);
            this.label5.TabIndex = 13;
            this.label5.Text = "Age";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(609, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = "Level";
            // 
            // StrengthBox
            // 
            this.StrengthBox.Location = new System.Drawing.Point(476, 92);
            this.StrengthBox.Name = "StrengthBox";
            this.StrengthBox.Size = new System.Drawing.Size(100, 22);
            this.StrengthBox.TabIndex = 15;
            // 
            // DexterityBox
            // 
            this.DexterityBox.Location = new System.Drawing.Point(661, 89);
            this.DexterityBox.Name = "DexterityBox";
            this.DexterityBox.Size = new System.Drawing.Size(100, 22);
            this.DexterityBox.TabIndex = 16;
            // 
            // ConstitutionBox
            // 
            this.ConstitutionBox.Location = new System.Drawing.Point(476, 120);
            this.ConstitutionBox.Name = "ConstitutionBox";
            this.ConstitutionBox.Size = new System.Drawing.Size(100, 22);
            this.ConstitutionBox.TabIndex = 17;
            // 
            // IntelligenceBox
            // 
            this.IntelligenceBox.Location = new System.Drawing.Point(661, 117);
            this.IntelligenceBox.Name = "IntelligenceBox";
            this.IntelligenceBox.Size = new System.Drawing.Size(100, 22);
            this.IntelligenceBox.TabIndex = 18;
            // 
            // WisdomBox
            // 
            this.WisdomBox.Location = new System.Drawing.Point(476, 148);
            this.WisdomBox.Name = "WisdomBox";
            this.WisdomBox.Size = new System.Drawing.Size(100, 22);
            this.WisdomBox.TabIndex = 19;
            // 
            // CharismaBox
            // 
            this.CharismaBox.Location = new System.Drawing.Point(661, 145);
            this.CharismaBox.Name = "CharismaBox";
            this.CharismaBox.Size = new System.Drawing.Size(100, 22);
            this.CharismaBox.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(443, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 17);
            this.label4.TabIndex = 21;
            this.label4.Text = "Str";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(620, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 17);
            this.label7.TabIndex = 22;
            this.label7.Text = "Dex";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(443, 122);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 17);
            this.label8.TabIndex = 23;
            this.label8.Text = "Con";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(628, 120);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 17);
            this.label9.TabIndex = 24;
            this.label9.Text = "Int";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(443, 151);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(31, 17);
            this.label10.TabIndex = 25;
            this.label10.Text = "Wis";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(622, 148);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 17);
            this.label11.TabIndex = 26;
            this.label11.Text = "Cha";
            // 
            // QuirkBox
            // 
            this.QuirkBox.Location = new System.Drawing.Point(661, 176);
            this.QuirkBox.Name = "QuirkBox";
            this.QuirkBox.Size = new System.Drawing.Size(100, 22);
            this.QuirkBox.TabIndex = 27;
            // 
            // IdealBox
            // 
            this.IdealBox.Location = new System.Drawing.Point(612, 288);
            this.IdealBox.Name = "IdealBox";
            this.IdealBox.Size = new System.Drawing.Size(149, 22);
            this.IdealBox.TabIndex = 28;
            // 
            // BondBox
            // 
            this.BondBox.Location = new System.Drawing.Point(661, 204);
            this.BondBox.Name = "BondBox";
            this.BondBox.Size = new System.Drawing.Size(100, 22);
            this.BondBox.TabIndex = 29;
            // 
            // TraitBox
            // 
            this.TraitBox.Location = new System.Drawing.Point(661, 232);
            this.TraitBox.Name = "TraitBox";
            this.TraitBox.Size = new System.Drawing.Size(100, 22);
            this.TraitBox.TabIndex = 30;
            // 
            // FlawBox
            // 
            this.FlawBox.Location = new System.Drawing.Point(661, 260);
            this.FlawBox.Name = "FlawBox";
            this.FlawBox.Size = new System.Drawing.Size(100, 22);
            this.FlawBox.TabIndex = 31;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(613, 181);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 17);
            this.label12.TabIndex = 32;
            this.label12.Text = "Quirk";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(565, 288);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 17);
            this.label13.TabIndex = 33;
            this.label13.Text = "Ideal";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(611, 204);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 17);
            this.label14.TabIndex = 34;
            this.label14.Text = "Bond";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(618, 232);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 17);
            this.label15.TabIndex = 35;
            this.label15.Text = "Trait";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(619, 260);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(36, 17);
            this.label16.TabIndex = 36;
            this.label16.Text = "Flaw";
            // 
            // TypeBox
            // 
            this.TypeBox.Location = new System.Drawing.Point(476, 176);
            this.TypeBox.Name = "TypeBox";
            this.TypeBox.Size = new System.Drawing.Size(100, 22);
            this.TypeBox.TabIndex = 37;
            // 
            // DiseaseBox
            // 
            this.DiseaseBox.Location = new System.Drawing.Point(476, 204);
            this.DiseaseBox.Name = "DiseaseBox";
            this.DiseaseBox.Size = new System.Drawing.Size(100, 22);
            this.DiseaseBox.TabIndex = 38;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(432, 176);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(40, 17);
            this.label17.TabIndex = 39;
            this.label17.Text = "Type";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(413, 204);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(59, 17);
            this.label18.TabIndex = 40;
            this.label18.Text = "Disease";
            // 
            // WeaponBox
            // 
            this.WeaponBox.Location = new System.Drawing.Point(661, 63);
            this.WeaponBox.Name = "WeaponBox";
            this.WeaponBox.Size = new System.Drawing.Size(100, 22);
            this.WeaponBox.TabIndex = 41;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(592, 63);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 17);
            this.label19.TabIndex = 42;
            this.label19.Text = "Weapon";
            // 
            // HPBox
            // 
            this.HPBox.Location = new System.Drawing.Point(476, 63);
            this.HPBox.Name = "HPBox";
            this.HPBox.Size = new System.Drawing.Size(100, 22);
            this.HPBox.TabIndex = 43;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(443, 68);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(27, 17);
            this.label20.TabIndex = 44;
            this.label20.Text = "HP";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 526);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.HPBox);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.WeaponBox);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.DiseaseBox);
            this.Controls.Add(this.TypeBox);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.FlawBox);
            this.Controls.Add(this.TraitBox);
            this.Controls.Add(this.BondBox);
            this.Controls.Add(this.IdealBox);
            this.Controls.Add(this.QuirkBox);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.CharismaBox);
            this.Controls.Add(this.WisdomBox);
            this.Controls.Add(this.IntelligenceBox);
            this.Controls.Add(this.ConstitutionBox);
            this.Controls.Add(this.DexterityBox);
            this.Controls.Add(this.StrengthBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxLevel);
            this.Controls.Add(this.textBoxAge);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.LevelBox);
            this.Controls.Add(this.AgeBox);
            this.Controls.Add(this.MonsterCheck);
            this.Controls.Add(this.DiseaseCheck);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NameBox);
            this.Controls.Add(this.Start);
            this.Name = "Form1";
            this.Text = "A Marverlous DND NPC Generator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Start;
        private System.Windows.Forms.TextBox NameBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox DiseaseCheck;
        private System.Windows.Forms.CheckBox MonsterCheck;
        private System.Windows.Forms.TextBox AgeBox;
        private System.Windows.Forms.TextBox LevelBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox textBoxAge;
        private System.Windows.Forms.TextBox textBoxLevel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox StrengthBox;
        private System.Windows.Forms.TextBox DexterityBox;
        private System.Windows.Forms.TextBox ConstitutionBox;
        private System.Windows.Forms.TextBox IntelligenceBox;
        private System.Windows.Forms.TextBox WisdomBox;
        private System.Windows.Forms.TextBox CharismaBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox QuirkBox;
        private System.Windows.Forms.TextBox IdealBox;
        private System.Windows.Forms.TextBox BondBox;
        private System.Windows.Forms.TextBox TraitBox;
        private System.Windows.Forms.TextBox FlawBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox TypeBox;
        private System.Windows.Forms.TextBox DiseaseBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox WeaponBox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox HPBox;
        private System.Windows.Forms.Label label20;
    }
}

