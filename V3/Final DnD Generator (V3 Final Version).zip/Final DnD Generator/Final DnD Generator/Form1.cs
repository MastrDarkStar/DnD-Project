﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_DnD_Generator
{
    public partial class Form1 : Form
    {
        LevelAgeStats Barbo = new LevelAgeStats();
        MonsterDisease Orcus = new MonsterDisease();
        NameNTraits Vilkas = new NameNTraits();
        WeaponHealth Quartermaster = new WeaponHealth();
        public Form1()
        {
            InitializeComponent();

        }


        private void StartClick(object sender, EventArgs e)
        {
            if (LevelBox.Text == "")
            {
                LevelBox.Text = "1";
            }
            Barbo.Level = Convert.ToInt32(LevelBox.Text);
            if (AgeBox.Text == "")
            {
                AgeBox.Text = "21";
            }
            Barbo.Age = Convert.ToInt32(AgeBox.Text);
            if (NameBox.Text == "")
            {
                NameBox.Text = "John Doe";
            }
            Barbo.genStrength();
            Barbo.genDexterity();
            Barbo.genConstitution();
            Barbo.genIntelligence();
            Barbo.genWisdom();
            Barbo.genCharisma();
            Barbo.genAge();
            Orcus.IsDiseased = DiseaseCheck.Checked;
            Orcus.genIllness();
            Orcus.IsMonster = MonsterCheck.Checked;
            Orcus.genType();
            Vilkas.MakingTraits();
            Quartermaster.Health(Barbo.Level);
            Quartermaster.Weapons();

            richTextBox1.Text = NameBox.Text;
            textBoxLevel.Text = Barbo.Level.ToString();
            textBoxAge.Text = Barbo.NewAge.ToString();
            StrengthBox.Text = Barbo.Strength.ToString();
            DexterityBox.Text = Barbo.Dexterity.ToString();
            ConstitutionBox.Text = Barbo.Constitution.ToString();
            IntelligenceBox.Text = Barbo.Intelligence.ToString();
            WisdomBox.Text = Barbo.Wisdom.ToString();
            CharismaBox.Text = Barbo.Charisma.ToString();
            HPBox.Text = Quartermaster.HP.ToString();
            WeaponBox.Text = Quartermaster.weapon.ToString();

            QuirkBox.Text = Vilkas.Quirk.ToString();
            IdealBox.Text = Vilkas.Ideal.ToString();
            BondBox.Text = Vilkas.Bond.ToString();
            TraitBox.Text = Vilkas.Trait.ToString();
            FlawBox.Text = Vilkas.Flaw.ToString();

            TypeBox.Text = Orcus.type;
            DiseaseBox.Text = Orcus.disease;
        }
    }
}
